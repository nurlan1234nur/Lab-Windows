﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorApp.Abstract
{
    public abstract class TooniiMashin
    {
        public int result {  get; set; }    
    }
}