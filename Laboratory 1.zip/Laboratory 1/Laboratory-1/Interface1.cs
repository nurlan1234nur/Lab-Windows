﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace Interfaces1
{
     public interface Interface1
    {
        
        void Add(int x);

        void Substract(int x);
    }
}
